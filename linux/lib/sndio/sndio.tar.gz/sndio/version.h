#define VERSION "sndio master"
